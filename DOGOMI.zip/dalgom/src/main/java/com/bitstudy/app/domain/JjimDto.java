package com.bitstudy.app.domain;

public class JjimDto {
    private Integer jjim_no;
    private Integer te_no;
    private Integer user_no;

    public JjimDto() {
    }

    public Integer getJjim_no() {
        return jjim_no;
    }

    public void setJjim_no(Integer jjim_no) {
        this.jjim_no = jjim_no;
    }

    public Integer getTe_no() {
        return te_no;
    }

    public void setTe_no(Integer te_no) {
        this.te_no = te_no;
    }

    public Integer getUser_no() {
        return user_no;
    }

    public void setUser_no(Integer user_no) {
        this.user_no = user_no;
    }
}
